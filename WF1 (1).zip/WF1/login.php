<!--
All eode is under the GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007.
-->
<!DOCTYPE html>
<html>
<head>
<!-- Page Title -->
<title>PDBF || WF1</title>
<!-- Import Bootstrap from CDN-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!--Extra Theme-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!--Import jQuary from CDN-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!-- Extra CSS -->
<style>
.text-center {
  text-align: center;
}
body {
  margin-top: 100px;
  background: #16a085;
}
</style>
</head>
<body>
<div class="container">
  <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
      <div class="panel panel-primary">
        <div class="panel-heading text-center"><h4>PDBF WF1 </h4></div> 
		<div class="panel-body">
		<form action="login.php" method="post">
          <div class="form-group">
            <label for="usr">Username:</label>
            <input type="text" name="username" placeholder="Username" class="form-control" id="usr">
          </div>
          <div class="form-group">
            <label for="pwd">Password:</label>
            <input type="password" name="password" placeholder="Password" class="form-control" id="pwd">
          </div>
      <input name="Submit" type="submit" class="btn btn-primary btn-sm btn-block" id="Submit" value="Log In "/>
            
        
        
        <p style="float: right;">Don't have an account? <a href="register.html">Register!</a></p>
        </form>

		</div>
		<div class="panel-footer">
		    


<?php
if(isset($_POST['Submit']))
{
//echo "Hello";

include("app/connect.php"); 



$match = "select * from staff where emp_no = '".$_POST['username']."'
and password = '".$_POST['password']."';"; 

$qry = mysql_query($match)
or die ("Could not match data because ".mysql_error());
$num_rows = mysql_num_rows($qry); 

if ($num_rows <= 0) { 
echo "Sorry, there is no username $emp_no with the specified password.<br>";

} else {

setcookie("loggedin", "TRUE", time()+(3600 * 24));
setcookie("site_username", "$emp_no");

print "<script>window.location='app/wf1.php'</script>";	
	exit;

} 
}

?>  
		    


	    
		</div>
      </div>
    </div>
  </div>
</div>




</body>
</html>
