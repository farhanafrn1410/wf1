<table border="1" width="200" height=100%>


<tr><td align="center"><div style="background-color:#D6D6D6;padding:5px 0px 5px 0px;"><a href ="news.php"> প্রথম পাত া</a></div></td></tr>

<tr><td align="center"><div style="background-color:#D6D6D6;padding:5px 0px 5px 0px;"><a href ="latestnewslist.php"> রিপোর্ট  </a></div></td></tr>


</table>
