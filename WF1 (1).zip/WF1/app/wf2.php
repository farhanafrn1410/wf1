
     
	<?php 
	
	include("connect.php");
if(isset($_REQUEST['branch_code'])){
// $rirt_no=$_REQUEST['report_no'];



$branch_code=$_REQUEST['branch_code'];


$query="SELECT * FROM idcode where branch_code='$branch_code'";
$result=mysql_query($query);

$fetch=mysql_fetch_array($result);
/*$emp_no=$_REQUEST['emp_no'];
$q="SELECT * FROM staff where emp_no='$emp_no'";
$r=mysql_query($q);
$f=mysql_fetch_array($r);*/
}


?>
<?php 
if(isset($_REQUEST['emp_no'])){
$emp_no=$_REQUEST['emp_no'];
$q="SELECT * FROM staff where emp_no='$emp_no'";
$r=mysql_query($q);
$f=mysql_fetch_array($r);

} 

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> PDBF</title>
<style>
body{
margin:auto;
background-color:#EAEAEA;
}
h1
{ font-size:30px;
color:#003399;
text-align:center;
font-family:"Times New Roman", Times, serif;
font-weight:700;
}
h2
{
text-align:center;
 color:#CC3333;
font-family:Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:28px;
}

t1
{

}
  @font-face
        {
            font-family: myUniFont;
            src: url(./SolaimanLipi_22-02-2012.ttf);
        }
t2{
    width: 30px;
    height: 10px;
    background-color: yellow;
    box-shadow: 10px 10px 5px #888888;
}



input[type='text'], input[type='password'], input[type='date']
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}

input[type='text']:hover, input[type='password']:hover
{
width: 200px;
height: 29px;
border-radius: 5px;
border: 1px solid #aaa;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}

input[type='submit']
{
width: 150px;
height: 34px;
border: 2px solid white;
background-color:#CCC;
}
input[type='submit']:hover
{
width: 150px;
height: 34px;
border: 2px solid white;
background-color:#000080;
color:#fff;
}

select
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}
select: hover
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}


</style>
</head>
<body>



<table border="1" width="1190" height="300" align="center">
         <tr>
              <td colspan="2" height="100"><img src="logo.jpg" style="width:1190px;height:128px;">
			       </td>
				        </tr>
          <tr>

                 <td valign="top" width="1190" height="300" align="center">
                      <p valign="top" width="1190" height="300" align="center"><br>
                               <h3 style="width: 450px;
                                   height: 40px;
                                   background-color: #000080;
                                   box-shadow: 10px 10px 5px #888888;text-align:center;color:white;font-style:Times New Roman;text-shadow: 4px 4px 7px #4682B4; font-size:27px;"> 
                                           WF1
										        </h3>
  												      </p>






<form name="f1" action="wf1.php" method="post" enctype="multipart/form-data">
  

	
	
	
	
<table border="0"width="1090">
     <tr>
	   <td> 
	        <div style="float:left;">
	                                কার্যালয় কোড: 
					    </div>
	
	        <div style="float:left; padding:0px 0px 0px 3px;">
	                  <input type="text" style="width:100px;" name="branch_code" id="branch_code" value="<?php echo isset($fetch)?$fetch['branch_code']:''?>" />
	   
	                  <input style="visibility:hidden;" type="button"  disabled>
					            </div>
	                                      </td>
	
	
	    <td> 
		    <div style="float:left;">
		              কার্যালয়ের নাম: </div>
		<div style="float:left; padding:0px 0px 0px 2px;">
		               <input type="text" style="width:170px;" name="branch_name" id="branch_name" value="<?php echo isset($fetch)?$fetch['branch_name']:''?>"/>
					               </div>
		                                   </td>
		
		<td> 
		         <div style="float:left;">
		                                                অঞ্চল:
           							 </div>
		
		         <div style="float:left; padding:0px 0px 0px 6px;">
		                    <input type="text" style="width:170px;" name="region_name" id="region_name" value="<?php echo isset($fetch)?$fetch['region_name']:''?>"/>
							         </div>
		                                  </td>
	 <td>
           <div style="float:left;">
                 কর্মীর আইডি : 
				              </div>
           <div style="float:left; padding:0px 0px 0px 6px;">
                       <input type="text" style="width:100px;" name="emp_no" id="emp_no" value="<?php echo isset($f)?$f['emp_no']:''?>" />
                       <input style="visibility:hidden;" type="button"  disabled>
      					       </div>
		                              </td>
   
	                                            </tr>
                                                       <tr></tr>	<tr></tr>	
	
   <tr>
 
      
	    <td>
	          <div style="float:left;">
	                 কর্মীর নাম: 
					          </div>
	          <div style="float:left; padding:0px 0px 0px 29px;">
                       <input type="text" style="width:170px;" name="emp_name" id="emp_name" value="<?php echo isset($f)?$f['emp_name']:''?>"/> 
					          </div>
		                              </td>
		
	    <td>
	           <div style="float:left;">
	                    পদবী: 
						        </div>
	           <div style="float:left; padding:0px 0px 0px 65px;">
                      <input type="text" style="width:170px;" name="designation" id="designation" value="<?php echo isset($f)? $f['designation']:''?>"/>
					           </div>
		                              </td>	

		<td>
              <div style="float:left">
                                              তারিখ:
					       </div> 
			  <div style="float:left; padding:0px 0px 0px 4px;">
		           <input type="date" style="width:170px;" name="date" id="date" />
				             </div>
							       </td>
		                                   </tr>	
										           </table>
		
		<br> <br> <br>
		
		
		
		
		<table border="0" width="1090">
		
     <tr>
         <td>
	           <div style="float:left;">
	                                             ৩. সপ্তাহের শুরুতে খেলাপী ঋণ:
						        </div>
	           <div style="float:left; padding:0px 0px 0px 61px;">
                      <input type="text" style="width:100px;" name="arrears_beg_week" id="arrears_beg_week"/>
					           </div>
		                              </td>	
									         
									  
									  
			<td>
	           <div style="float:left;">
	                                                 ৪. চলতি সপ্তাহে ঋণ বিতরণ :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 15px;">
                      <input type="text" style="width:100px;" name="loan_dis_week" id="loan_dis_week"/>
					           </div>
		                              </td>							  
									  
									  
			<td>
	           <div style="float:left;">
	                                                 ৫. চলতি ঋণ আদায়যোগ্য :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 109px;">
                      <input type="text" style="width:100px;" name="rec_current_loan" id="rec_current_loan"/>
					           </div>
		                              </td>	
									        </tr>
                                               
		<tr>									   
			<td>
	           <div style="float:left;">
	                                               ৬. চলতি ঋণ আদায়যোগ্য থেকে আদায় :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 5px;">
                      <input type="text" style="width:100px;" name="earning_rec_amount" id="earning_rec_amount"/>
					           </div>
		                              </td>		   
											   
											   
			<td>
	           <div style="float:left;">
	                                                   ৭. মোট ঋণ আদায় :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 74px;">
                      <input type="text" style="width:100px;" name="total_rec_loan" id="total_rec_loan"/>
					           </div>
		                              </td>									   
											   
			<td>
	           <div style="float:left;">
	                                                ৮. চলতি ঋণ আদায়ের হার :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 102px;">
                      <input type="text" style="width:100px;" name="current_bor_rate" id="current_bor_rate"/>
					           </div>
		                              </td>									   
											  </tr> 
											        

	<tr>									   
			<td>
	           <div style="float:left;">
	                                       ৯. জিএসএস (গত সপ্তাহ) :
						         </div>
	           <div style="float:left; padding:0px 0px 0px 91px;">
                      <input type="text" style="width:100px;" name="last_week_gss" id="last_week_gss"/>
					           </div>
		                              </td>									   
									  
			<td>
	           <div style="float:left;">
	                                           ১০. জিএসএস (চলতি সপ্তাহ) :
						         </div>
	           <div style="float:left; padding:0px 0px 0px 8px;">
                      <input type="text" style="width:100px;" name="this_week_gss" id="this_week_gss"/>
					           </div>
		                              </td>							  
									        
			
		
			<td>
	           <div style="float:left;">
	                                           ১১. এসএসএস (গত সপ্তাহ) :
						              </div>
	           <div style="float:left; padding:0px 0px 0px 95px;">
                      <input type="text" style="width:100px;" name="last_week_sss" id="last_week_sss"/>
					           </div>
							          </td>
	
	<tr>                           							  
			<td>
	           <div style="float:left;">
	                   ১২. এসএসএস (চলতি সপ্তাহ) :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 60px;">
                      <input type="text" style="width:100px;" name="this_week_sss" id="this_week_sss"/>
					           </div>
		                              </td>							  
									          
									  
									                                    
         <td>
	           <div style="float:left;">
	                                                   ১৩. মেয়াদী সঞ্চয় স্থিতি :
						               </div>
	           <div style="float:left; padding:0px 0px 0px 48px;">
                      <input type="text" style="width:100px;" name="term_deposit_status" id="term_deposit_status"/>
					           </div>
		                              </td>			
        

		<td>
	           <div style="float:left;">
	                                             ১৪. সপ্তাহান্তে (মাঠে পাওনা ঋণের পরিমাণ) :
						                </div>
	           <div style="float:left; padding:0px 0px 0px 1px;">
                      <input type="text" style="width:100px;" name="loan_amount_field" id="loan_amount_field"/>
					           </div>
		                              </td>	 
									       </tr>
										        </table>
												<br> <br>
										  
    
<table border="0" width="1090">	
	<tr>                                       
	
		<td>
	           <div style="float:left;">
	                                       ১৫. সপ্তাহান্তে কিস্তি খেলাপী (টাকা) :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 31px;">
                      <input type="text" style="width:100px;" name="ins_arrears_amount" id="ins_arrears_amount"/>
					           </div>
		                              </td>									  
        <td>
	           <div style="float:left;">
	                                           ১৬. সপ্তাহান্তে কিস্তি খেলাপী (সংখ্যা):
						        </div>
	           <div style="float:left; padding:0px 0px 0px 4px;">
                      <input type="text" style="width:100px;" name="ins_arrears_number" id="ins_arrears_number"/>
					           </div>
		                              </td>			
									        
	  
								                                    
           <td>
	           <div style="float:left;">
	                                              ১৭. সপ্তাহান্তে মেয়াদ খেলাপী (টাকা)  :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 4px;">
                      <input type="text" style="width:100px;" name="odi_amount" id="odi_amount"/>
					           </div>
		                              </td>	 
									        </tr>
		<tr>							  
	       <td>
	           <div style="float:left;">
	                                          ১৮. সপ্তাহান্তে মেয়াদ খেলাপী (সংখ্যা)  :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 16px;">
                      <input type="text" style="width:100px;" name="odi_number" id="odi_number"/>
					           </div>
		                              </td>	
	  
	     					  
			<td>
	           <div style="float:left;">
	                                                   ১৯.  মোট খেলাপী :
						             </div>
	           <div style="float:left; padding:0px 0px 0px 120px;">
                      <input type="text" style="width:100px;" name="total_arrears" id="total_arrears"/>
					           </div>
		                              </td>	
			<td>
	           <div style="float:left;">
	                                                 ২০.  চলতি বছরে মোট ঋণ বিতরণ :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 16px;">
                      <input type="text" style="width:100px;" name="loan_dis_year" id="loan_dis_year"/>
					           </div>
		                              </td>	
									        </tr>
									  
		<tr>	
			<td>
	           <div style="float:left;">
	                                          ২১.  চলতি বছরে মোট ঋণ আদায়যোগ্য :
						            </div>
	           <div style="float:left; padding:0px 0px 0px 5px;">
                      <input type="text" style="width:100px;" name="total_rec_loan_year" id="total_rec_loan_year"/>
					           </div>
		                              </td>	
									  
	        <td>
	           <div style="float:left;">
	                                          ২২. চলতি বছরে মোট ঋণ আদায় :
						            </div>
	           <div style="float:left; padding:0px 0px 0px 16px;">
                      <input type="text" style="width:100px;" name="total_loan_rev_year" id="total_loan_rev_year"/>
					           </div>
		                              </td>	                                       
			
			
			<td>
	           <div style="float:left;">
	                                               ২৩. বার্ষিক আদায়ের হার :
						        </div>
	           <div style="float:left; padding:0px 0px 0px 74px;">
                      <input type="text" style="width:100px;" name="annual_col_rate" id="annual_col_rate"/>
					           </div>
		                              </td>							         
											 
											 
											 </tr>
									                      </table>
	  
	 
    
		
		
		
		
		

    <div style="padding:50px 0px 0px 0px;">
    
        <input type="submit" value="submit">
    
    </div>
 
  <?php 

$branch_code=$_REQUEST['branch_code'];
$branch_name=$_REQUEST['branch_name'];
$region_name=$_REQUEST['region_name'];
$date=$_REQUEST['date'];
$emp_name=$_REQUEST['emp_name'];
$arrears_beg_week=$_REQUEST['arrears_beg_week'];
$loan_dis_week=$_REQUEST['loan_dis_week'];
$rec_current_loan=$_REQUEST['rec_current_loan'];
$earning_rec_amount=$_REQUEST['earning_rec_amount'];
$total_rec_loan=$_REQUEST['total_rec_loan'];
$current_bor_rate=$_REQUEST['current_bor_rate'];
$last_week_gss=$_REQUEST['last_week_gss'];
$this_week_gss=$_REQUEST['this_week_gss'];
$last_week_sss=$_REQUEST['last_week_sss'];
$this_week_sss=$_REQUEST['this_week_sss'];
$term_deposit_status=$_REQUEST['term_deposit_status'];
$loan_amount_field=$_REQUEST['loan_amount_field'];
$ins_arrears_amount=$_REQUEST['ins_arrears_amount'];
$ins_arrears_number=$_REQUEST['ins_arrears_number'];
$odi_amount=$_REQUEST['odi_amount'];
$odi_number=$_REQUEST['odi_number'];
$total_arrears=$_REQUEST['total_arrears'];
$loan_dis_year=$_REQUEST['loan_dis_year'];
$total_rec_loan_year=$_REQUEST['total_rec_loan_year'];
$total_loan_rev_year=$_REQUEST['total_loan_rev_year'];
$annual_col_rate=$_REQUEST['annual_col_rate'];


$a="insert into mic(branch_code,branch_name,region_name,date,emp_name,arrears_beg_week,loan_dis_week,rec_current_loan,earning_rec_amount,total_rec_loan,current_bor_rate,last_week_gss,this_week_gss,last_week_sss,this_week_sss,term_deposit_status,loan_amount_field,ins_arrears_amount,ins_arrears_number,odi_amount,odi_number,total_arrears,loan_dis_year,total_loan_rev_year,total_rec_loan_year,annual_col_rate) values ('$branch_code','$branch_name','$region_name','$date','$emp_name','$arrears_beg_week','$loan_dis_week','$rec_current_loan','$earning_rec_amount','$total_rec_loan','$current_bor_rate','$last_week_gss','$this_week_gss','$last_week_sss','$this_week_sss','$term_deposit_status','$loan_amount_field','$ins_arrears_amount','$ins_arrears_number','$odi_amount','$odi_number','$total_arrears','$loan_dis_year','$total_loan_rev_year','$total_rec_loan_year','$annual_col_rate')";

mysql_query($a);

?>
  
  
</form>
</td></tr>
</table>
</body>
</html>
