<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> PDBF</title>
<style>
body{
margin:auto;
background-color:#EAEAEA;
}
h1
{ font-size:30px;
color:#003399;
text-align:center;
font-family:"Times New Roman", Times, serif;
font-weight:700;
}
h2
{
text-align:center;
 color:#CC3333;
font-family:Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:28px;
}

t1
{

}
  @font-face
        {
            font-family: myUniFont;
            src: url(./SolaimanLipi_22-02-2012.ttf);
        }
t2{
    width: 30px;
    height: 10px;
    background-color: yellow;
    box-shadow: 10px 10px 5px #888888;
}



input[type='text'], input[type='password'], input[type='date']
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}

input[type='text']:hover, input[type='password']:hover
{
width: 200px;
height: 29px;
border-radius: 5px;
border: 1px solid #aaa;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}




select
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}
select: hover
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}


</style>
</head>
<body>

<table border="1" width="990" height="0" align="center">
          <tr>
             <td colspan="2" height="100"><img src="logo.jpg" style="width:990px;height:100px;">
			     </td>
				      </tr>
</table>
					  
					  
<br><br>
                    <form name="f2" action="wf1list3.php" method="post" enctype="multipart/form-data">
                          <table border="0"width="1090"align="center">
                            <tr>
	                        <td> 
	                           <div style="float:left;">
	                                                     কার্যালয় কোড: 
					                </div>
	
	                            <div style="float:left; padding:0px 0px 0px 0px;">
	                                    <input type="text" style="width:100px;" name="branch_code" id="branch_code" />
	   
	                  
					                     </div>
	                                            </td>
		
		
		 <td>
           <div style="float:left;">
                 কর্মীর আইডি : 
				              </div>
           <div style="float:left; padding:0px 0px 0px 0px;">
                       <input type="text" style="width:100px;" name="emp_no" id="emp_no" value="<?php echo isset($f)?$f['emp_no']:''?>" />
                       
      					       </div>
		                              </td>
										  
		<td>
              <div style="float:left">
                                              তারিখ:
					       </div> 
			  <div style="float:left; padding:0px 0px 0px 0px;">
		           <input type="date" style="width:170px;" name="date" id="date" />
				             </div>
							       </td>
								   
												
			<td>
              <div style="float:left">
                                              শেষ তারিখ:
					       </div> 
			  <div style="float:left; padding:0px 0px 0px 0px;">
		           <input type="date" style="width:170px;" name="enddate" id="enddate" />
				             </div>
							       </td>
								   <td>   
    
                                            <input type="submit" value="submit">
    
                                             
	                                            </td>							   			
												</tr> 
                                                    </table>					  								  
											
													

			<br><br>										
	
	
	
	
</form>
</body>
</html>