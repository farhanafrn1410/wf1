<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> PDBF</title>
<style>
body{
margin:auto;
background-color:#EAEAEA;
}
h1
{ font-size:30px;
color:#003399;
text-align:center;
font-family:"Times New Roman", Times, serif;
font-weight:700;
}
h2
{
text-align:center;
 color:#CC3333;
font-family:Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:28px;
}

t1
{

}
  @font-face
        {
            font-family: myUniFont;
            src: url(./SolaimanLipi_22-02-2012.ttf);
        }
t2{
    width: 30px;
    height: 10px;
    background-color: yellow;
    box-shadow: 10px 10px 5px #888888;
}



input[type='text'], input[type='password'], input[type='date']
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}

input[type='text']:hover, input[type='password']:hover
{
width: 200px;
height: 29px;
border-radius: 5px;
border: 1px solid #aaa;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}




select
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}
select: hover
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}


</style>
</head>
<body>

<table border="1" width="990" height="0" align="center">
          <tr>
             <td colspan="2" height="100"><img src="logo.jpg" style="width:990px;height:100px;">
			     </td>
				      </tr>
</table>
					  
					  
<br><br>
                    <form name="f2" action="wf1list3.php" method="post" enctype="multipart/form-data">
                          <table border="0"width="1090"align="center">
                            <tr>
	                        <td> 
	                           <div style="float:left;">
	                                                     কার্যালয় কোড: 
					                </div>
	
	                            <div style="float:left; padding:0px 0px 0px 0px;">
	                                    <input type="text" style="width:100px;" name="branch_code" id="branch_code" />
	   
	                  
					                     </div>
	                                            </td>
		
		
		 <td>
           <div style="float:left;">
                 কর্মীর আইডি : 
				              </div>
           <div style="float:left; padding:0px 0px 0px 0px;">
                       <input type="text" style="width:100px;" name="emp_no" id="emp_no" value="<?php echo isset($f)?$f['emp_no']:''?>" />
                       
      					       </div>
		                              </td>
									  
		<td>
              <div style="float:left">
                                              শুরু তারিখ:
					       </div> 
			  <div style="float:left; padding:0px 0px 0px 0px;">
		           <input type="date" style="width:170px;" name="date" id="date" />
				             </div>
							       </td>
								   
								   
		<td>
              <div style="float:left">
                                              শেষ তারিখ:
					       </div> 
			  <div style="float:left; padding:0px 0px 0px 0px;">
		           <input type="date" style="width:170px;" name="enddate" id="enddate" />
				             </div>
							       </td>
								   <td>   
    
                                            <input type="submit" value="submit">
    
                                             
	                                            </td>
										   			</tr> 
                                                         </table>					  								  
											
													

			<br><br>										
	
<table border="1"  align="center" >
<tr>
<td  align="center"><b>উপজেলা/ কার্যালয় কোড</b></td>


<td  align="center"><b>কর্মীর আইডি</b></td>
<td  align="center"><b>২. কর্মীর নাম</b></td>
<td  align="center"><b>তারিখ</b></td>
<td  align="center"><b>৩. সপ্তাহের শুরুতে খেলাপী ঋণ <br> সার্ভিস চার্জসহ</b></td>
<td  align="center"><b>৪. চলতি সপ্তাহে ঋণ বিতরণ</b></td>
<td  align="center"><b>৫. চলতি ঋণ আদায়যোগ্য </b></td>
<td  align="center"><b>৬. চলতি ঋণ আদায়যোগ্য থেকে আদায়</b></td>
<td  align="center"><b>৭. মোট ঋণ আদায়</b></td>
<td  align="center"><b>৮. চলতি ঋণ আদায়ের হার  <br> ৫/৪*১০০</b></td>
<td  align="center"><b>৯. জিএসএস (গত সপ্তাহ)</b></td>
<td  align="center"><b>১০. জিএসএস (চলতি সপ্তাহ)</b></td>
<td  align="center"><b>১১. এসএসএস (গত সপ্তাহ) </b></td>
<td  align="center"><b> ১২. এসএসএস (চলতি সপ্তাহ) </b></td>
<td  align="center"><b>১৩. মেয়াদী সঞ্চয় স্থিতি </b></td>
<td  align="center"><b>১৪. সপ্তাহান্তে (মাঠে পাওনা ঋণের পরিমাণ)</b></td>
<td  align="center"><b>  ১৫. সপ্তাহান্তে কিস্তি খেলাপী (টাকা) </b></td>
<td  align="center"><b> ১৬. সপ্তাহান্তে কিস্তি খেলাপী (সংখ্যা)</b></td>
<td  align="center"><b>১৭. সপ্তাহান্তে মেয়াদ খেলাপী (টাকা) </b></td>
<td align="center"><b>  ১৮. সপ্তাহান্তে মেয়াদ খেলাপী (সংখ্যা)</b></td>
<td align="center"><b>১৯.  মোট খেলাপী</b></td>

<td  align="center"><b> ২০.  চলতি বছরে মোট ঋণ বিতরণ </b></td>
<td  align="center"><b>  ২১.  চলতি বছরে মোট ঋণ আদায়যোগ্য</b></td>
<td align="center"><b>২২. চলতি বছরে মোট ঋণ আদায় </b></td>

<td  align="center"><b> ২৩. বার্ষিক আদায়ের হার</b></td>



<td align="center" ><b>Action</b></td>
</tr>



<?php

include ("connect.php");




$branch_code=$_REQUEST['branch_code'];
$emp_no=$_REQUEST['emp_no'];
$date=$_REQUEST['date'];
$enddate=$_REQUEST['enddate'];

$query="SELECT * FROM  mic where branch_code='$branch_code' and emp_no='$emp_no' and date between '$date' and '$enddate'";
$result=mysql_query($query);

$result1 = mysql_query("SELECT sum(arrears_beg_week),sum(loan_dis_week),sum(rec_current_loan),sum(earning_rec_amount),sum(total_rec_loan),sum(current_bor_rate),
	sum(last_week_gss),sum(this_week_gss),sum(last_week_sss),sum(this_week_sss),sum(term_deposit_status),sum(loan_amount_field),sum(ins_arrears_amount),sum(ins_arrears_number),sum(odi_amount),sum(odi_number),sum(total_arrears),sum(loan_dis_year),sum(total_rec_loan_year),sum(total_loan_rev_year),sum(annual_col_rate)
	FROM mic ");

while($row=mysql_fetch_array($result))
{
?>

<tr><td valign="top" align="center">
<?php echo $row['branch_code'];?>
</td>

<td valign="top" align="center">
<?php echo $row['emp_no'];

?>
</td>

<td valign="top" align="center">
<?php echo $row['emp_name'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['date'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['arrears_beg_week'];

?>
</td>

<td valign="top" align="center">
<?php echo $row['loan_dis_week'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['rec_current_loan'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['earning_rec_amount'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['total_rec_loan'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['current_bor_rate'];

?>
</td><td valign="top" align="center">
<?php echo $row['last_week_gss'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['this_week_gss'];

?>
</td><td valign="top" align="center">
<?php echo $row['last_week_sss'];

?>
</td><td valign="top" align="center">
<?php echo $row['this_week_sss'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['term_deposit_status'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['loan_amount_field'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['ins_arrears_amount'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['ins_arrears_number'];

?>
</td><td valign="top" align="center">
<?php echo $row['odi_amount'];

?>
</td><td valign="top" align="center">
<?php echo $row['odi_number'];

?>
</td><td valign="top" align="center">
<?php echo $row['total_arrears'];

?>
</td><td valign="top" align="center">
<?php echo $row['loan_dis_year'];

?>
</td><td valign="top" align="center">
<?php echo $row['total_rec_loan_year'];

?>
</td><td valign="top" align="center">
<?php echo $row['total_loan_rev_year'];

?>
</td><td valign="top" align="center">
<?php echo $row['annual_col_rate'];

?>
</td>





<td valign="top"> <a href ="edit.php?id=<?php echo $row ['id']; ?>"> <img src="edit.ico" alt="Edit" height="18" width="18">Edit  </a>
&nbsp; <a href ="delete.php?id=<?php echo $row['id'];?>"> <img src="delete.ico" alt="Delete" height="18" width="18"> Delete </a>
</td>
</tr>






<?php
}

?>
<?php


	while($row = mysql_fetch_array($result1))
 {
	 ?>
	 
	<tr><td valign="top" align="center">
সর্বমোট
</td>

<td valign="top" align="center">

</td>

<td valign="top" align="center">

<td valign="top" align="center">

</td>
<td valign="top" align="center">
<?php echo $row['sum(arrears_beg_week)'];

?>
</td>

<td valign="top" align="center">
<?php echo $row['sum(loan_dis_week)'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['sum(rec_current_loan)'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['sum(earning_rec_amount)'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['sum(total_rec_loan)'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['sum(current_bor_rate)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(last_week_gss)'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['sum(this_week_gss)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(last_week_sss)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(this_week_sss)'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['sum(term_deposit_status)'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['sum(loan_amount_field)'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['sum(ins_arrears_amount)'];

?>
</td>
<td valign="top" align="center">
<?php echo $row['sum(ins_arrears_number)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(odi_amount)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(odi_number)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(total_arrears)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(loan_dis_year)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(total_rec_loan_year)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(total_loan_rev_year)'];

?>
</td><td valign="top" align="center">
<?php echo $row['sum(annual_col_rate)'];

?>
</td>


<?php
}
?>
 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	






 </table>
</form>
</body>
</html>