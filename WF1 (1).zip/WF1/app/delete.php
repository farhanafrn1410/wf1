<?php 
/*ob_start(); ?>

	<?php 
	
    include("connect.php");
	?>
	
	  <!-- content start-->
	     <?php 
		   $cid = $_REQUEST['id']; 
		   
		   $sql = "delete from news where  id= $cid";
		   mysql_query($sql);
		   
		   header('Location:newslist.php');
           //echo "data has been delete sucecessfully";
 		   */
		   
		   
		   
		   ob_start();
		   include ("connect.php");
		   $cid=$_REQUEST['id'];
		   $a="delete  from mic where id=$cid";
		   mysql_query($a);
		   
		   
		 ?>
