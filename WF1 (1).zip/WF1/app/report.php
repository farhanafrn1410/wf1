<!--
All eode is under the GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007.
-->
<!DOCTYPE html>
<html>
<head>
    
    
    
    
    
    <?php 
include("connect.php");
$currentWeekNumber = date('W');

if(isset($_REQUEST['branch_code'])){
$branch_code=$_REQUEST['branch_code'];
$query="SELECT * FROM idcode where branch_code='$branch_code'";
$result=mysql_query($query);
$fetch=mysql_fetch_array($result);
}
?>

<?php 
if(isset($_REQUEST['emp_no'])){
$emp_no=$_REQUEST['emp_no'];
$q="SELECT * FROM staff where emp_no='$emp_no'";
$r=mysql_query($q);
$f=mysql_fetch_array($r);
} 
?>
<!--date and week funtion-->
<?php
/*
$previous_week = strtotime("-1 week +1 day");

$start_week = strtotime("last sunday midnight",$previous_week);
$end_week = strtotime("next saturday",$start_week);

$start_week = date("Y-m-d",$start_week);
$end_week = date("Y-m-d",$end_week);

echo $start_week.' '.$end_week ; */

if(isset($_REQUEST['emp_no'])){
$emp_no=$_REQUEST['emp_no'];

$d="SELECT * FROM MIC 
 WHERE emp_no='$emp_no' and date BETWEEN CURDATE()-INTERVAL 1 WEEK AND CURDATE()";
$d2=mysql_query($d);
$d3=mysql_fetch_array($d2);
echo $d3['loan_dis_year'];
}
?>

<!--end-->


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> PDBF</title>
<style>
body{
margin:auto;
background-color:#EAEAEA;
}
h1
{ font-size:30px;
color:#003399;
text-align:center;
font-family:"Times New Roman", Times, serif;
font-weight:700;
}
h2
{
text-align:center;
 color:#CC3333;
font-family:Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:28px;
}

t1
{

}
  @font-face
        {
            font-family: myUniFont;
            src: url(./SolaimanLipi_22-02-2012.ttf);
        }
t2{
    width: 30px;
    height: 10px;
    background-color: yellow;
    box-shadow: 10px 10px 5px #888888;
}



input[type='text'], input[type='password'], input[type='date']
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}

input[type='text']:hover, input[type='password']:hover
{
width: 200px;
height: 29px;
border-radius: 5px;
border: 1px solid #aaa;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}

input[type='submit']
{
width: 150px;
height: 34px;
border: 2px solid white;
background-color:#CCC;
}
input[type='submit']:hover
{
width: 150px;
height: 34px;
border: 2px solid white;
background-color:#000080;
color:#fff;
}

select
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}
select: hover
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}


</style>

    
    
    
    
    
    
    
    
<!-- Import Bootstrap from CDN-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!--Extra Theme-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<!--Import jQuary from CDN-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!-- Extra CSS -->
<style>
.text-right {
  float: right;
}
body {
  background: #16a085;
}
</style>
</head>
<body>
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#" style="color:white;">PDBF || WF1 Online Form </a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="wf1.php">Home</a></li>
      <li><a href="report.php">Report</a></li>
      
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="../register.html"><span class="glyphicon glyphicon-user"></span> Register</a></li>
      <li><a href="../login.php"><span class="glyphicon glyphicon-log-in"></span> Log Out</a></li>
    </ul>
  </div>
</nav>
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-primary"> 
	     <div class="panel-heading"><br>
	  </div>
	<form id="form1" name="form1" method="post" action="">
	  <tr><td><p>&nbsp;</p>
	  <table width="90%" border="0" align="center">
            <tr>
              <td width="14%" >Employee Code </td>
              <td width="21%" ><input name="branchcode2" type="text" id="branchcode2"/></td>
              
              <td width="11%" >Branch Code </td>
              <td width="22%" ><input name="branchcode" type="text" id="branchcode"/></td></tr>
                             
            <tr>
              <td >Start Date </td>
              <td ><input type="date" name="date" id="date" required /></td>
              
              <td >End date </td>
              <td ><input type="date" name="enddate" id="enddate" required/>              </td></tr>
              </tr><tr> <td colspan="4"><br></td> </tr>
              
              <tr><td colspan="4" align="center">  <input type="submit" name="Submit" value="Submit" /></td>
            </tr>
        </table>		  
		  <p>
		  
		  <div style="height:100%;width:100%;border:1px solid #ccc;font:16px/26px Georgia, Garamond, Serif;overflow:auto;">
		    <div align="center">
		      <?php	
		if(isset($_POST['Submit']))
{
include 'connect.php';
mysql_query("SET CHARACTER SET utf8");
mysql_query("SET SESSION collation_connection =utf8_general_ci"); 
$branch=$_POST['branchcode'];
$empcode=$_POST['branchcode2'];
$date=$_REQUEST['date'];
$enddate=$_REQUEST['enddate'];

$query ="SELECT * FROM mic where branch_code  LIKE '%{$branch}%' AND emp_no LIKE '%{$empcode}%' AND (date BETWEEN '$date' and '$enddate') ";


//$value=$_POST['value'];
//echo $in2;
//echo $value;

$results11=mysql_query($query);

     echo "<table border='1' width='480' height='50' align='center' >
     <tr>
	 
	 <th align='center'>উপজেলা/ কার্যালয় কোড</th>
	 <th align='center'>তারিখ</th>
	 <th align='center'> কর্মীর আইডি </th>
	 <th align='center'> ২. কর্মীর নাম </th>
	  <th align='center'> ৩. সপ্তাহের শুরুতে খেলাপী ঋণ <br> সার্ভিস চার্জসহ</b> </th>
	   <th align='center'>৪. চলতি সপ্তাহে ঋণ বিতরণ</th>
	   <th align='center'>৫. চলতি ঋণ আদায়যোগ্য </th>
	   <th align='center'>৬. চলতি ঋণ আদায়যোগ্য থেকে আদায়</th>
	 <th align='center'>৭. মোট ঋণ আদায়</th>
	 <th align='center'>৮. চলতি ঋণ আদায়ের হার </th>
	 <th align='center'> ৯. জিএসএস (গত সপ্তাহ)</th>
	  <th align='center'>১০. জিএসএস (চলতি সপ্তাহ)</th>
	   <th align='center'>১১. এসএসএস (গত সপ্তাহ)</th>
	   <th align='center'> ১২. এসএসএস (চলতি সপ্তাহ) </th>
	   <th align='center'><b>১৩. মেয়াদী সঞ্চয় স্থিতি </b></th>
	 <th align='center'><b>১৪. সপ্তাহান্তে (মাঠে পাওনা ঋণের পরিমাণ)</b></th>
	 <th align='center'><b>  ১৫. সপ্তাহান্তে কিস্তি খেলাপী (টাকা) </b></th>
	 <th align='center'><b> ১৬. সপ্তাহান্তে কিস্তি খেলাপী (সংখ্যা)</b></th>
	  <th align='center'><b>১৭. সপ্তাহান্তে মেয়াদ খেলাপী (টাকা) </b></th>
	   <th align='center'><b>  ১৮. সপ্তাহান্তে মেয়াদ খেলাপী (সংখ্যা)</b></th>
	   <th align='center'> <b>১৯.  মোট খেলাপী</b> </th>
	   
	  <th align='center'><b> ২০.  চলতি বছরে মোট ঋণ বিতরণ </b></th>
	 <th align='center'><b>  ২১.  চলতি বছরে মোট ঋণ আদায়যোগ্য) </b></th>
	 <th align='center'><b> ২২. চলতি বছরে মোট ঋণ আদায়</b></th>
	  <th align='center'><b>২৩. বার্ষিক আদায়ের হার </b></th>
	  <th align='center'><b>Action</b></th>
	  
	 


     </tr>";



while($row = mysql_fetch_array($results11))
	{
								
echo "<tr>";
  echo "<td valign='top' align='center' >" . $row['branch_code'] . "</td>";
  echo "<td >" . $row['date'] . "</td>";
  echo "<td >" . $row['emp_no'] . "</td>"; 
  echo "<td >" . $row['emp_name'] . "</td>"; 
  
  echo "<td >" . $row['arrears_beg_week'] . "</td>";
  echo "<td >" . $row['loan_dis_week'] . "</td>";
  echo "<td >" . $row['rec_current_loan'] . "</td>"; 
  echo "<td >" . $row['earning_rec_amount'] . "</td>"; 
  echo "<td >" . $row['total_rec_loan'] . "</td>"; 
  echo "<td >" . $row['current_bor_rate'] . "</td>";
  echo "<td >" . $row['last_week_gss'] . "</td>";
  echo "<td >" . $row['this_week_gss'] . "</td>";
   echo "<td >" . $row['last_week_sss'] . "</td>"; 
  echo "<td >" . $row['this_week_sss'] . "</td>"; 
  echo "<td >" . $row['term_deposit_status'] . "</td>"; 
  echo "<td >" . $row['loan_amount_field'] . "</td>";
  echo "<td >" . $row['ins_arrears_amount'] . "</td>";
  echo "<td >" . $row['ins_arrears_number'] . "</td>";
   echo "<td >" . $row['odi_amount'] . "</td>"; 
  echo "<td >" . $row['odi_number'] . "</td>"; 
  echo "<td >" . $row['total_arrears'] . "</td>"; 
  echo "<td >" . $row['loan_dis_year'] . "</td>";
  echo "<td >" . $row['total_rec_loan_year'] . "</td>";
  echo "<td >" . $row['total_loan_rev_year'] . "</td>";
   echo "<td >" . $row['annual_col_rate'] . "</td>"; 
   
   
   
     }
   echo "</table>";
   
}

?>
            </div>
	    </div>
		  </p></td>
        
      
</form>    </td>
  </tr>
 <br>
</td></tr>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  
    $("#date").change(function(){
          var d = $("#date").val();
    var b_code = $("#branch_code").val();
    var e_no = $("#emp_no").val();
       
        $.post("wf1_check.php",
        {
          date:d,
          b_code: b_code,
          e_no: e_no
        },
        function(data){
             var d = JSON.parse(data)
            if(d[0])
            {
           
            console.log(d);
            $("#annual_col_rate").val(d.annual_col_rate);
            $("#arrears_beg_week").val(d.arrears_beg_week);
            $("#current_bor_rate").val(d.current_bor_rate);
            $("#earning_rec_amount").val(d.earning_rec_amount);
            $("#ins_arrears_amount").val(d.ins_arrears_amount);
            $("#ins_arrears_number").val(d.ins_arrears_number);
            $("#last_week_gss").val(d.last_week_gss);
            $("#last_week_sss").val(d.last_week_sss);
            $("#loan_amount_field").val(d.loan_amount_field);
            $("#loan_dis_week").val(d.loan_dis_week);
            $("#loan_dis_year").val(d.loan_dis_year);
            $("#odi_amount").val(d.odi_amount);
            $("#odi_number").val(d.odi_number);
            $("#rec_current_loan").val(d.rec_current_loan);
            $("#term_deposit_status").val(d.term_deposit_status);
            $("#this_week_gss").val(d.this_week_gss);
            $("#this_week_sss").val(d.this_week_sss);
            $("#total_arrears").val(d.total_arrears);
            $("#total_loan_rev_year").val(d.total_loan_rev_year);
            $("#total_rec_loan").val(d.total_rec_loan);
            $("#total_rec_loan_year").val(d.total_rec_loan_year);
            $('#myform').attr('action', 'wf1_update.php?id='+d[0]);
            $("#submit").val('Update');
            }
            else
            {
                $("#annual_col_rate").val('');
            $("#arrears_beg_week").val('');
            $("#current_bor_rate").val('');
            $("#earning_rec_amount").val('');
            $("#ins_arrears_amount").val('');
            $("#ins_arrears_number").val('');
            $("#last_week_gss").val('');
            $("#last_week_sss").val('');
            $("#loan_amount_field").val('');
            $("#loan_dis_week").val('');
            $("#loan_dis_year").val('');
            $("#odi_amount").val('');
            $("#odi_number").val('');
            $("#rec_current_loan").val('');
            $("#term_deposit_status").val('');
            $("#this_week_gss").val('');
            $("#this_week_sss").val('');
            $("#total_arrears").val('');
            $("#total_loan_rev_year").val('');
            $("#total_rec_loan").val('');
            $("#total_rec_loan_year").val('');
             $('#myform').attr('action', 'wf1.php');
             $("#submit").val('Submit');
            }
            
        });
    });
});
</script>
		 </div>
      </div>
    </div>
	<!--<div class="col-md-3">
	  <div class="panel panel-primary"> 
	   
	</div>
  </div>-->
<!-- Copyright & Credits bar-->
<div class="panel panel-primary">
<div class="panel-heading">Copyright &copy; <a href="#"><font color="black"></font></a> 2016, All Rights Reserved.<span class="text-right">PDBF IT Dept.<font color="black"></font></a></span></div>
</div>
</div>
</body>
</html>
