<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PDBF Employee List</title>
<style>
body{
margin:auto;
background-color:#EAEAEA;
}
h1
{ font-size:30px;
color:#003399;
text-align:center;
font-family:"Times New Roman", Times, serif;
font-weight:700;
}
h2
{
text-align:center;
 color:#CC3333;
font-family:Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:28px;
}

input[type='submit']
{
width: 150px;
height: 34px;
border: 2px solid white;
background-color:#CCC;
}
input[type='submit']:hover
{
width: 150px;
height: 34px;
border: 2px solid white;
background-color:#000080;
color:#fff;
}
</style>
</head>
<body>



<table border="1" width="990" height="300" align="center">
<tr>
<td colspan="2" height="100"><img src="logo.jpg" style="width:990px;height:100px;"></td></tr>
<tr>
<?php 
include ("connect.php");


if(isset($_REQUEST['branch_code'])){
// $rirt_no=$_REQUEST['report_no'];



$branch_code=$_REQUEST['branch_code'];
$emp_no=$_REQUEST['emp_no'];
$date=$_REQUEST['date'];


$query="SELECT * FROM  mic where branch_code='$branch_code' && emp_no='$emp_no' && date='$date'";
$result=mysql_query($query);

?>

<td valign="top" width="990" height="300" align="center"><br>
<h3 style="width: 500px;
    height: 55px;
    background-color: #000080;
    box-shadow: 10px 10px 5px #888888;text-align:center;color:white;font-style:Times New Roman;text-shadow: 4px 4px 7px #4682B4; font-size:21px;"> 
Search Your Info  </h3>

<table border="0"width="1090">
     <tr>
	   <td> 
	        <div style="float:left;">
	                                ???????? ???: 
					    </div>
	
	        <div style="float:left; padding:0px 0px 0px 3px;">
	                  <input type="text" style="width:100px;" name="branch_code" id="branch_code" />
	   
	                  
					            </div>
	                                      </td>
		
		
		<td> 
	        <div style="float:left;">
	                  ???????? ???: 
					    </div>
	
	        <div style="float:left; padding:0px 0px 0px 3px;">
	                  <input type="text" style="width:100px;" name="branch_code" id="branch_code" />
	   
	                  
					            </div>
	                                      </td>
										  
		<td> 
	        <div style="float:left;">
	                                ???????? ???: 
					    </div>
	
	        <div style="float:left; padding:0px 0px 0px 3px;">
	                  <input type="text" style="width:100px;" name="branch_code" id="branch_code" />
	   
	                  
					            </div>
	                                      </td>
										   			</tr> </table>					  								  

<table border="1" width="480"height="50" align="center" >
<tr>
<td width="40" align="center"><b>Employee No</b></td>
<td align="center"width="200"><b>Employee Name</b></td>


<td align="center" width="140"><b>Action</b></td>
</tr>






<?php
include ("connect.php");

$a="select * from user";
$result=mysql_query ($a);



while($row=mysql_fetch_array($result))
{
?>

<tr><td valign="top" align="center">
<?php echo $row['empno'];?>
</td>

<td valign="top" align="center">
<?php echo $row['empname'];

?>
</td>






<td valign="top"><a href="view.php?id=<?php echo $row['id']; ?>" ><img src="view.ico"  alt="View" height="18" width="18"> View  </a>
&nbsp; <a href ="edit.php?id=<?php echo $row ['id']; ?>"> <img src="edit.ico" alt="Edit" height="18" width="18">Edit  </a>
&nbsp; <a href ="delete.php?id=<?php echo $row['id'];?>"> <img src="delete.ico" alt="Delete" height="18" width="18"> Delete </a>
</td>
</tr>



<?php
}

?>

</table>
<br> <br>
<form name="f1" action="logout.php" method="post" enctype="multipart/form-data">

<input type="submit" value="Logout" align="center"> </form>
</td></tr>




</table></br>
</body>
</html>
