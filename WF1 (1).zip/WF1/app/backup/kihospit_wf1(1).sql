-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2018 at 12:15 PM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kihospit_wf1`
--

-- --------------------------------------------------------

--
-- Table structure for table `idcode`
--

CREATE TABLE IF NOT EXISTS `idcode` (
  `branch_code` varchar(200) NOT NULL,
  `branch_name` varchar(200) NOT NULL,
  `region_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `idcode`
--

INSERT INTO `idcode` (`branch_code`, `branch_name`, `region_name`) VALUES
('1111', 'xyz', 'dhaka'),
('1212', 'dhaka', 'dhaka'),
('2222', 'bangladesh', 'bangladesh');

-- --------------------------------------------------------

--
-- Table structure for table `mic`
--

CREATE TABLE IF NOT EXISTS `mic` (
`id` int(11) NOT NULL,
  `branch_code` varchar(150) NOT NULL,
  `branch_name` varchar(150) NOT NULL,
  `region_name` varchar(150) NOT NULL,
  `date` date NOT NULL,
  `week` int(11) NOT NULL,
  `emp_no` varchar(150) NOT NULL,
  `emp_name` varchar(150) NOT NULL,
  `arrears_beg_week` varchar(150) NOT NULL,
  `loan_dis_week` varchar(150) NOT NULL,
  `rec_current_loan` varchar(150) NOT NULL,
  `earning_rec_amount` varchar(150) NOT NULL,
  `total_rec_loan` varchar(150) NOT NULL,
  `current_bor_rate` varchar(150) NOT NULL,
  `last_week_gss` varchar(150) NOT NULL,
  `this_week_gss` varchar(150) NOT NULL,
  `last_week_sss` varchar(150) NOT NULL,
  `this_week_sss` varchar(150) NOT NULL,
  `term_deposit_status` varchar(150) NOT NULL,
  `loan_amount_field` varchar(150) NOT NULL,
  `ins_arrears_amount` varchar(150) NOT NULL,
  `ins_arrears_number` varchar(150) NOT NULL,
  `odi_amount` varchar(150) NOT NULL,
  `odi_number` varchar(150) NOT NULL,
  `total_arrears` varchar(150) NOT NULL,
  `loan_dis_year` varchar(150) NOT NULL,
  `total_loan_rev_year` varchar(150) NOT NULL,
  `total_rec_loan_year` varchar(150) NOT NULL,
  `annual_col_rate` varchar(150) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=281 ;

--
-- Dumping data for table `mic`
--

INSERT INTO `mic` (`id`, `branch_code`, `branch_name`, `region_name`, `date`, `week`, `emp_no`, `emp_name`, `arrears_beg_week`, `loan_dis_week`, `rec_current_loan`, `earning_rec_amount`, `total_rec_loan`, `current_bor_rate`, `last_week_gss`, `this_week_gss`, `last_week_sss`, `this_week_sss`, `term_deposit_status`, `loan_amount_field`, `ins_arrears_amount`, `ins_arrears_number`, `odi_amount`, `odi_number`, `total_arrears`, `loan_dis_year`, `total_loan_rev_year`, `total_rec_loan_year`, `annual_col_rate`) VALUES
(276, '1111', 'xyz', 'dhaka', '2018-02-01', 6, '04719', 'Farhana Rahman', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '6', '3', '3', '9', '3'),
(277, '1111', 'xyz', 'dhaka', '2018-02-08', 6, '04719', 'Farhana Rahman', '3', '3', '3', '3', '3', '3', '3', '3', '33', '3', '3', '3', '3', '3', '3', '3', '6', '6', '3', '9', '3');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `emp_no` varchar(200) NOT NULL,
  `emp_name` varchar(200) NOT NULL,
  `designation` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`emp_no`, `emp_name`, `designation`) VALUES
('045', 'dfdf', 'fsdfdf'),
('04719', 'Farhana Rahman', 'Assistant Programmer'),
('04720', 'MM', 'AP'),
('04721', 'AB', 'Assistant Programmer'),
('04722', 'CD', 'Assistant Programmer');

-- --------------------------------------------------------

--
-- Table structure for table `wf1`
--

CREATE TABLE IF NOT EXISTS `wf1` (
`id` int(11) NOT NULL,
  `branch_code` varchar(100) NOT NULL,
  `branch_name` varchar(100) NOT NULL,
  `region_name` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `arrears_beg_week` varchar(100) NOT NULL,
  `loan_dis_week` varchar(100) NOT NULL,
  `rec_current_loan` varchar(100) NOT NULL,
  `earning_rec_amount` varchar(100) NOT NULL,
  `total_rec_loan` varchar(100) NOT NULL,
  `current_bor_rate` varchar(100) NOT NULL,
  `last_week_gss` varchar(100) NOT NULL,
  `this_week_gss` varchar(100) NOT NULL,
  `last_week_sss` varchar(100) NOT NULL,
  `this_week_sss` varchar(100) NOT NULL,
  `term_deposit_status` varchar(100) NOT NULL,
  `loan_amount_field` varchar(100) NOT NULL,
  `ins_arrears_amount` varchar(100) NOT NULL,
  `ins_arrears_number` varchar(100) NOT NULL,
  `odi_amount` varchar(100) NOT NULL,
  `odi_number` varchar(100) NOT NULL,
  `total_arrears` varchar(100) NOT NULL,
  `loan_dis_year` varchar(100) NOT NULL,
  `total_loan_rev_year` varchar(100) NOT NULL,
  `total_rec_loan_year` varchar(100) NOT NULL,
  `annual_col_rate` varchar(100) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `wf1`
--

INSERT INTO `wf1` (`id`, `branch_code`, `branch_name`, `region_name`, `date`, `emp_name`, `arrears_beg_week`, `loan_dis_week`, `rec_current_loan`, `earning_rec_amount`, `total_rec_loan`, `current_bor_rate`, `last_week_gss`, `this_week_gss`, `last_week_sss`, `this_week_sss`, `term_deposit_status`, `loan_amount_field`, `ins_arrears_amount`, `ins_arrears_number`, `odi_amount`, `odi_number`, `total_arrears`, `loan_dis_year`, `total_loan_rev_year`, `total_rec_loan_year`, `annual_col_rate`) VALUES
(1, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, '1111', 'xyz', 'dhaka', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, '1111', 'xyz', 'dhaka', '2018-01-02', 'dfdf', '12', '12', '12', '21', '21', '1221', '123', '12', '12', '12', '12', '12', '12', '12', '12', '12', '212', '12', '12', '1221', '12'),
(5, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(6, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(7, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(8, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(9, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(10, '1111', 'xyz', 'dhaka', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, '', '', '', '2018-01-08', '', '12', '2', '12', '12', '2', '12', '2', '12', '12', '12', '12', '12', '12', '21', '12', '12', '12', '', '12', '12', '2121'),
(12, '12', '1221', '12', '2018-01-15', '12', '456', '12', '45', '12', '21', '12', '12', '12', '12', '12', '12', '45', '45', '45', '45', '45', '45', '45', '54', '54', '45'),
(13, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(14, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(15, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(16, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(17, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(18, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(19, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(20, '123', '123', '456', '2018-01-10', 'fgfd', 'fgd', 'fdg', 'dfg', 'fdg', 'gfg', 'gf', 'gf', 'fg', 'dfg', 'dfg', 'dfg', 'g', 'gf', 'fdg', 'gfg', 'dfg', 'df', 'dgdfg', 'df', 'gf', 'dfggf'),
(21, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(22, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(23, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(24, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(25, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(26, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(27, '1111', 'xyz', 'dhaka', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(28, '1111', 'xyz', 'dhaka', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(29, '1111', 'xyz', 'dhaka', '2018-01-08', 'dfdf', 'another', 'gfhgfhh', 'fgf', 'gfsg', 'df', 'd', 'fgsdg', 'dgdf', 'gg', 'gsfd', 'd', 'fdgfd', 'ggf', 'gffg', 'fgfg', 'ffgf', 'gfg', 'fgf', 'gfgfgf', 'fdgdfg', 'fgfdf'),
(30, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(31, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(32, '1111', 'xyz', 'dhaka', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(33, '1111', 'xyz', 'dhaka', '2018-01-08', 'dfdf', 'another', 'gfhg', 'gsdf', 'fgsfg', 'fgsdg', 'gf', 'fg', 'g', 'fdg', 'fgdsg', 'fgsdf', 'fdg', 'gfsdf', 'fg', 'ff', 'ggf', 'gfgf', 'fdg', 'dfdfg', 'gf', 'fdg'),
(34, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(35, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(36, '1111', 'xyz', 'dhaka', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(37, '1111', 'xyz', 'dhaka', '2018-01-10', 'dfdf', '4545', '455', '45656', '456', '456', '', '456', '456', '56456', '456', '456', '4564', '6', '45645645', '456456', '456', '456', '456', '456', '456', '456'),
(38, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(39, '1111', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(40, '1111', 'xyz', 'dhaka', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(41, '1111', 'xyz', 'dhaka', '2018-01-08', 'dfdf', 'jkhjk', 'jkhjk', 'hjkhjk', 'hkk', 'hjkhjk', 'hjk', 'hjkhjk', 'khjk', 'hjk', 'hjk', 'hjkhj', 'khjk', 'hjkhjk', 'hjkhjk', 'hjkjk', 'jkhjk', 'khj', 'hjk', 'hjkhj', 'jhkhjk', 'hjk'),
(42, '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(43, 'hgfhgfh', 'ghfg', 'gfhgfh', '2018-01-07', 'gfhgfh', 'ghfgh', 'gfhgfh', 'h', 'ghgfh', 'ghfh', 'gfhgf', 'gh', 'gh', 'gfhgfh', 'ghgfh', 'ghgh', 'ghfh', 'gff', 'gfh', 'g', 'gf', 'gh', 'h', 'fgh', 'gfhg', 'gfh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `idcode`
--
ALTER TABLE `idcode`
 ADD PRIMARY KEY (`branch_code`), ADD UNIQUE KEY `branch_code` (`branch_code`), ADD UNIQUE KEY `branch_code_2` (`branch_code`);

--
-- Indexes for table `mic`
--
ALTER TABLE `mic`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `date` (`date`), ADD UNIQUE KEY `date_2` (`date`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
 ADD PRIMARY KEY (`emp_no`);

--
-- Indexes for table `wf1`
--
ALTER TABLE `wf1`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mic`
--
ALTER TABLE `mic`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=281;
--
-- AUTO_INCREMENT for table `wf1`
--
ALTER TABLE `wf1`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
