<?php 
	include("connect.php");
	$date = $_POST['date'];
	$b_code = $_POST['b_code'];
	$e_no = $_POST['e_no'];

$q="SELECT * FROM mic where branch_code='$b_code' and emp_no ='$e_no' and date = '$date'";
$r=mysql_query($q);
$f=mysql_fetch_array($r);
echo json_encode($f);
	?>