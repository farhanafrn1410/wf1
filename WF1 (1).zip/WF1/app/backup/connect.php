<?php

mysql_connect("localhost","gournadi_wf1","77Sci@90");
mysql_select_db("gournadi_wf1");



?>

