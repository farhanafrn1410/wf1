<?php
 echo date(DATE_RFC2822);

?>