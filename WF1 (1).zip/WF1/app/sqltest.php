    
<?php 
include("connect.php");
mysql_query("SET CHARACTER SET utf8");
mysql_query("SET SESSION collation_connection =utf8_general_ci"); 


$results11=mysql_query("SELECT loan_dis_year FROM `mic` WHERE date = (SELECT MAX(date) FROM mic where emp_no= 04719)");

  

while($row = mysql_fetch_array($results11))
	{

  $asd=$row['loan_dis_year'] ; 
 }
  
  echo $asd;
?>