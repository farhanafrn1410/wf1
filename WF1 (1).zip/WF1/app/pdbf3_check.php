<?php 
	include("connect.php");
	$emp_no = $_POST['emp_no'];
	

$q="SELECT * FROM staff where emp_no = '$emp_no'";
$r=mysql_query($q);
$f=mysql_fetch_array($r);
echo json_encode($f);
	?>