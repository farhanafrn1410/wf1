<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> PDBF</title>
<style>
body{
margin:auto;
background-color:#EAEAEA;
}
h1
{ font-size:30px;
color:#003399;
text-align:center;
font-family:"Times New Roman", Times, serif;
font-weight:700;
}
h2
{
text-align:center;
 color:#CC3333;
font-family:Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:28px;
}

t1
{

}
  @font-face
        {
            font-family: myUniFont;
            src: url(./SolaimanLipi_22-02-2012.ttf);
        }
t2{
    width: 30px;
    height: 10px;
    background-color: yellow;
    box-shadow: 10px 10px 5px #888888;
}



input[type='text'], input[type='password'], input[type='date']
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}

input[type='text']:hover, input[type='password']:hover
{
width: 200px;
height: 29px;
border-radius: 5px;
border: 1px solid #aaa;
padding: 8px;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}

select
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}
select: hover
{
width: 200px;
height: 29px;
border-radius: 3px;
border: 1px solid #CCC;
font-weight: 200;
font-size: 15px;
font-family: Verdana;
box-shadow: 1px 1px 5px #CCC;
}

</style>
</head>
<body>

<table border="1" width="990" height="0" align="center">
          <tr>
             <td colspan="2" height="100"><img src="logo.jpg" style="width:990px;height:100px;">
			     </td>
				      </tr>
</table>
	<form id="form1" name="form1" method="post" action="">  <br>			
<table width="980" border="0" align="center">
  <tr>
    <td >   
        Branch code
            <input name="branchcode" type="text" id="branchcode"style="width:100px;" />
              </td>
	  
	  <td>
        Employee code
        <input name="branchcode2" type="text" id="branchcode2"style="width:100px;" />
		    </td>

<td>
              <div style="float:left">
                                              শুরু তারিখ:
					       </div> 
			  <div style="float:left; padding:0px 0px 0px 0px;">
		           <input type="date" style="width:170px;" name="date" id="date" />
				             </div>
							       </td>
								   
								   
							   
		<td>
              <div style="float:left">
                                              শেষ তারিখ:
					       </div> 
			  <div style="float:left; padding:0px 0px 0px 0px;">
		           <input type="date" style="width:170px;" name="enddate" id="enddate" />
				             </div>
							       </td>
								  


			
		<td><input type="submit" name="Submit" value="Submit" /></td>
        
      
    </form>    </td>
  </tr></table>
 <br>
	<?php	
		if(isset($_POST['Submit']))
{
include 'connect.php';
mysql_query("SET CHARACTER SET utf8");
mysql_query("SET SESSION collation_connection =utf8_general_ci"); 
$branch=$_POST['branchcode'];
$empcode=$_POST['branchcode2'];
$date=$_REQUEST['date'];
$enddate=$_REQUEST['enddate'];

$query ="SELECT * FROM mic where ";
if(!empty($branch))
	$query .= "branch_code='$branch' and ";//Add branch_code in where condition if branch is not empty
if(!empty ($empcode))
	$query .= "emp_no='$empcode' and ";//Like branch code
if(!empty ($date and $enddate))
	$query .= " date='$date' and ";	
	
	
	
if(substr($query,strlen($query)-6 ,strlen($query))=="where ")
// if where condition is empty then need to remove where keyword from query
$query =substr($query,0,strlen($query)-7); // To remove where keyword

else

$query=substr($query,0,(strlen($query)-4));// To remove last and operator. like where


//$value=$_POST['value'];
//echo $in2;
//echo $value;

$results11=mysql_query($query);

     echo "<table border='1' width='480' height='50' align='center' >
     <tr>
	 
	 <th align='center'>উপজেলা/ কার্যালয় কোড</th>
	 <th align='center'>তারিখ</th>
	 <th align='center'> কর্মীর আইডি </th>
	 <th align='center'> ২. কর্মীর নাম </th>
	  <th align='center'> ৩. সপ্তাহের শুরুতে খেলাপী ঋণ <br> সার্ভিস চার্জসহ</b> </th>
	   <th align='center'>৪. চলতি সপ্তাহে ঋণ বিতরণ</th>
	   <th align='center'>৫. চলতি ঋণ আদায়যোগ্য </th>
	   <th align='center'>৬. চলতি ঋণ আদায়যোগ্য থেকে আদায়</th>
	 <th align='center'>৭. মোট ঋণ আদায়</th>
	 <th align='center'>৮. চলতি ঋণ আদায়ের হার </th>
	 <th align='center'> ৯. জিএসএস (গত সপ্তাহ)</th>
	  <th align='center'>১০. জিএসএস (চলতি সপ্তাহ)</th>
	   <th align='center'>১১. এসএসএস (গত সপ্তাহ)</th>
	   <th align='center'> ১২. এসএসএস (চলতি সপ্তাহ) </th>
	   <th align='center'><b>১৩. মেয়াদী সঞ্চয় স্থিতি </b></th>
	 <th align='center'><b>১৪. সপ্তাহান্তে (মাঠে পাওনা ঋণের পরিমাণ)</b></th>
	 <th align='center'><b>  ১৫. সপ্তাহান্তে কিস্তি খেলাপী (টাকা) </b></th>
	 <th align='center'><b> ১৬. সপ্তাহান্তে কিস্তি খেলাপী (সংখ্যা)</b></th>
	  <th align='center'><b>১৭. সপ্তাহান্তে মেয়াদ খেলাপী (টাকা) </b></th>
	   <th align='center'><b>  ১৮. সপ্তাহান্তে মেয়াদ খেলাপী (সংখ্যা)</b></th>
	   <th align='center'> <b>১৯.  মোট খেলাপী</b> </th>
	   
	  <th align='center'><b> ২০.  চলতি বছরে মোট ঋণ বিতরণ </b></th>
	 <th align='center'><b>  ২১.  চলতি বছরে মোট ঋণ আদায়যোগ্য) </b></th>
	 <th align='center'><b> ২২. চলতি বছরে মোট ঋণ আদায়</b></th>
	  <th align='center'><b>২৩. বার্ষিক আদায়ের হার </b></th>
	  <th align='center'><b>Action</b></th>
	  
	 


     </tr>";



while($row = mysql_fetch_array($results11))
	{
								
echo "<tr>";
  echo "<td valign='top' align='center' >" . $row['branch_code'] . "</td>"; 
  echo "<td >" . $row['emp_no'] . "</td>"; 
  echo "<td >" . $row['emp_name'] . "</td>"; 
  echo "<td >" . $row['date'] . "</td>";
  echo "<td >" . $row['arrears_beg_week'] . "</td>";
  echo "<td >" . $row['loan_dis_week'] . "</td>";
  echo "<td >" . $row['rec_current_loan'] . "</td>"; 
  echo "<td >" . $row['earning_rec_amount'] . "</td>"; 
  echo "<td >" . $row['total_rec_loan'] . "</td>"; 
  echo "<td >" . $row['current_bor_rate'] . "</td>";
  echo "<td >" . $row['last_week_gss'] . "</td>";
  echo "<td >" . $row['this_week_gss'] . "</td>";
   echo "<td >" . $row['last_week_sss'] . "</td>"; 
  echo "<td >" . $row['this_week_sss'] . "</td>"; 
  echo "<td >" . $row['term_deposit_status'] . "</td>"; 
  echo "<td >" . $row['loan_amount_field'] . "</td>";
  echo "<td >" . $row['ins_arrears_amount'] . "</td>";
  echo "<td >" . $row['ins_arrears_number'] . "</td>";
   echo "<td >" . $row['odi_amount'] . "</td>"; 
  echo "<td >" . $row['odi_number'] . "</td>"; 
  echo "<td >" . $row['total_arrears'] . "</td>"; 
  echo "<td >" . $row['loan_dis_year'] . "</td>";
  echo "<td >" . $row['total_rec_loan_year'] . "</td>";
  echo "<td >" . $row['total_loan_rev_year'] . "</td>";
   echo "<td >" . $row['annual_col_rate'] . "</td>"; 
   
   
   
     }
   echo "</table>";
   
}

?> 

</body>
</html>
