<html><head><title></title>
<style>

#menu 
{
    /*Styling the menu width and height*/
    list-style:none;
    margin:1px auto 0px auto;
    width:300px;
    height:27px;
    padding:0px 0px 0px 0px;
     
  /* Creating the curved corner of the border*/
    border-radius:5px;
    -moz-border-radius:5px;
    -webkit-border-radius:5px;
 
  /*Styling the background with fading effect*/
    background:#D3D3D3;
    background: -moz-linear-gradient(top, #000,	#E0FFFF );
    background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#000), to( 	#E0FFFF));
     
  /*Making the shadow effect into the menu bar */
    box-shadow: outset 10px 10px 15px 0066FF;
    -moz-box-shadow: outset 10px 15px 15px #0066FF;
    -webkit-box-shadow: outset 10px 15px 15px #0066FF;
    border:1px solid #FFFFFF;
     
     
}
#menu li /*Styling the li part of the menu*/
{
    float:left;
    padding:2px 0px 4px 45px;
    display: block;
    position:relative;
    text-align:center;
    margin-right:10px;
    margin-top:7px;
    border:none;
    /*color:#CCCCCC;*/
     
}
 
#menu li a /*Styling the link part of the menu li*/
{
    text-decoration:none;
	font-size:14px;

	
    color:#191970;
    text-shadow:5px 5px 13px 	#FDF5E6;
}
#menu li:hover a /*Styling the link part of the menu li in hover state*/
{
    color:#7B68EE;
    text-shadow:2px 2px 13px #FFFFFF;

}
</style>
</head>
<body>




<table>

<tr><td> 
<ul id="menu"  >

<li><a href="wf1.php"> প্রথম পাতা </a></li>


 
 <li><a href ="test2.php"> রিপোর্ট </a></li>


 </ul>
 </td></tr>

</table>
