<html>
<head>
<title> The News</title>
<style>
body{
margin:auto;
background-color:#EAEAEA;
}
h1
{ font-size:30px;
color:#003399;
text-align:center;
font-family:"Times New Roman", Times, serif;
font-weight:700;
}
h2
{
text-align:center;
 color:#CC3333;
font-family:Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:28px;
}
</style>
</head>
<body>



<table border="1" width="990" height="300" align="center">
<tr>
<td colspan="2" height="100"><h1>Welcome to Admin Panel</h1></td></tr>
<tr>
<td valign="top" width="200" >
<?php include("menu.php");
include ("connect.php");
$a="select * from category";
$b=mysql_query ($a);
?>
</td>

<td valign="top" width="900" height="300" >
<h1>News</h1>






<form name="f1" action="news_action.php" method="post" enctype="multipart/form-data">
  
   
	
	    
    <div style="clear:both; padding:10px 80px 0px 200px">
    
    
      <div style="float:left">
  
      Category Id:
	  </div>
	  <div style="float:left; padding:0px 0px 0px 16px;">
	  
        
		<select name="CategoryId" id="CategoryId">
		<?php while($row=mysql_fetch_array($b))
		{
		?>
		<option value ="<?php echo $row['id'];?>">
		<?php echo  $row['Category']; ?>
		
		</option>
		<?php
		}
		?>
		</select>
		</div>
		</div>
		


      
	  
       





	<div style="clear:both; padding:10px 80px 0px 200px">
    
    
      <div style="float:left">
  
      Title:
	  </div>
	  <div style="float:left; padding:0px 0px 0px 60px;">
	  
        <input type="text" name="Title" id="Title" />
		</div>
		</div>
   
   
   
   
   
   
   <div style="clear:both; padding: 10px 80px 0px 200px;">
   
         <div style="float:left">

    
          Description:</div>
		  <div style="float:left; padding:0px 0px 0px 15px;">
        <textarea rows="10" column="10" name="Description" id="Description"></textarea>
    </div>
    </div>
 
 
 
 
 
 
 
 
	
	<div style="clear:both; padding:10px 80px 0px 200px">
    
    
      <div style="float:left">
  
      Date:
	  </div>
	  <div style="float:left; padding:0px 0px 0px 60px;">
	  
        <input type="text" name="Date" id="Date" />
		</div>
		</div>
		
		
		
		
		
		<!--image start-->
	<div style="clear:both; padding:10px 80px 0px 200px">
    
		 <div style="float:left">
		     Image:
		</div>
		<div style="float:left; padding:0px 0px 0px 50px;">
		     <input type="file" name="file" id="file">
		</div>
	</div>
	<!--image end-->	
		
		
	
	
	
	
	
    
    
    
    <div style="clear:both; padding:10px 0px 0px 295px;">
    
      
      <input type="submit" value="submit">
    
    </div>
    
  
  
</form>
</td></tr>
</table>
</body>
</html>
