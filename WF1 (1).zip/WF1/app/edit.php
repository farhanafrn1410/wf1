<html>
<head>
<title> The News</title>
<style>
body{
margin:auto;
background-color:EAEAEA;
}
h1
{ font-size:30px;
color:#003399;
text-align:center;
font-family:"Times New Roman", Times, serif;
font-weight:700;
}
h2
{
text-align:center;
 color:#CC3333;
font-family:Arial, Helvetica, sans-serif;
font-weight:bold;
font-size:28px;
}
</style>
</head>
<body>



<table border="1" width="990" height="300" align="center">
<tr>
<td colspan="2" height="100"><h1>Welcome to Admin Panel</h1></td></tr>
<tr>
<td valign="top" width="200" height="430">
<?php include("menu.php");
?>
</td>

<td valign="top" width="900" height="300">
<h1>News</h1>








<form name="f1" action="edit_action.php" method="post">
  
   
	
	    
    
      


<?php

include ("connect.php");
$e="select * from category";
$z=mysql_query ($e);
$cid=$_REQUEST['id'];
$sql="select * from news where id=$cid";
$b=mysql_query ($sql);
$row    = mysql_fetch_array($b);
$Id=$row ['id'];
$CategoryId=$row ['CategoryId'];
$Title=$row ['Title'];
$Description=$row ['Description'];
$Date=$row ['Date'];
$Image=$row ['image'];




/*
	  include("connect.php");
	   $cid = $_REQUEST['id'];
	   
	   $sql= "select * from news where id=$cid";
	   $result = mysql_query($sql);
	   $row    = mysql_fetch_array($result);
	   $Title = $row['Title'];
	   $Description = $row['Description'];
	   
	   */
	?>





<div style="clear:both; padding:10px 80px 0px 80px">
    
    
	  <div style="float:left; padding:0px 0px 0px 60px;">
	  
        <input type="hidden" name="id" value="<?php echo $cid; ?> ">
			

		</div>
		</div>




   <div style="clear:both; padding:10px 80px 0px 200px">
    
    
      <div style="float:left">
  
      CategoryId:
	  </div>
	  <div style="float:left; padding:0px 0px 0px 16px;">
	  <select name="CategoryId" id="CtegoryId">
	  <?php
	  while ($row=mysql_fetch_array($z))
	  {
	  ?>
	  
	  <option value="<?php echo $row['id'];?>"  >
	  <?php echo $row['Category'];?>
	  </option>
	  <?php
	  }
	  ?>
	  </select>
	  
        
		</div>
		</div>
   





	<div style="clear:both; padding:10px 80px 0px 200px">
    
    
      <div style="float:left">
  
      Title:
	  </div>
	  <div style="float:left; padding:0px 0px 0px 60px;">
	  
        <input type="text" name="Title" id="Title" value="<?php echo $Title;?>" />
		</div>
		</div>
   
   
   
   
   
   
   <div style="clear:both; padding: 10px 80px 0px 200px;">
   
         <div style="float:left">

    
          Description:</div>
		  <div style="float:left; padding:0px 0px 0px 15px;">
        <textarea rows="10" column="10" name="Description" id="Description" value="<?php echo $Description;?>"  ><?php echo $Description;?></textarea>
    </div>
    </div>
 
	
	
	
	
	
	
	
    

	<div style="clear:both; padding:10px 80px 0px 200px">
    
    
      <div style="float:left">
  
      Date:
	  </div>
	  <div style="float:left; padding:0px 0px 0px 60px;">
	  
        <input type="text" name="Date" id="Date" value="<?php echo $Date;?>" />
		</div>
		</div>
   
   
   
   		
		<!--image start-->
	<div style="clear:both; padding:10px 80px 0px 200px">
    
		 <div style="float:left">
		     Image:
		</div>
		<div style="float:left; padding:0px 0px 0px 50px;">
		     <input type="file" name="file" id="file" value="<?php echo $Image;?>">
		</div>
	</div>
	<!--image end-->	
		

   
   
   
	 
       
    
    
    
    
    <div style="clear:both; padding:10px 0px 0px 295px;">
    
      
      <input type="submit" value="submit">
    
    </div>
    
  
  
</form>
</td></tr>
</table>
</body>
</html>
