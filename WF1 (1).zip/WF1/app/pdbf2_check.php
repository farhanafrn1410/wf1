<?php 
	include("connect.php");
	$branch_code = $_POST['branch_code'];
	

$q="SELECT * FROM idcode where branch_code = '$branch_code'";
$r=mysql_query($q);
$f=mysql_fetch_array($r);
echo json_encode($f);
	?>