<?php ob_start();

include ("connect.php");
$cid=$_REQUEST['id'];
$CategoryId=$_REQUEST['CategoryId'];

$Title=$_REQUEST['Title'];
$Description=$_REQUEST['Description'];
$Date=$_REQUEST['Date'];
$Image=$_REQUEST['file'];



$sql="update news set CategoryId='$CategoryId', Title='$Title', Description='$Description' ,Date='$Date',image ='$Image' where id ='$cid' ";
$b=mysql_query ($sql);
header('Location:newslist.php');


?>

