<?php ob_start();

include ("connect.php");
$id = $_GET['id'];
$branch_code=$_REQUEST['branch_code'];
$branch_name=$_REQUEST['branch_name'];
$region_name=$_REQUEST['region_name'];
$date=$_REQUEST['date'];
$emp_no=$_REQUEST['emp_no'];
$emp_name=$_REQUEST['emp_name'];
$arrears_beg_week=$_REQUEST['arrears_beg_week'];
$loan_dis_week=$_REQUEST['loan_dis_week'];
$rec_current_loan=$_REQUEST['rec_current_loan'];
$earning_rec_amount=$_REQUEST['earning_rec_amount'];
$total_rec_loan=$_REQUEST['total_rec_loan'];
$current_bor_rate=$_REQUEST['current_bor_rate'];
$last_week_gss=$_REQUEST['last_week_gss'];
$this_week_gss=$_REQUEST['this_week_gss'];
$last_week_sss=$_REQUEST['last_week_sss'];
$this_week_sss=$_REQUEST['this_week_sss'];
$term_deposit_status=$_REQUEST['term_deposit_status'];
$loan_amount_field=$_REQUEST['loan_amount_field'];
$ins_arrears_amount=$_REQUEST['ins_arrears_amount'];
$ins_arrears_number=$_REQUEST['ins_arrears_number'];
$odi_amount=$_REQUEST['odi_amount'];
$odi_number=$_REQUEST['odi_number'];
$total_arrears=$ins_arrears_amount+$odi_amount;
$loan_dis_year=$_REQUEST['loan_dis_year'];

$total_loan_rev_year=$_REQUEST['total_loan_rev_year'];
$total_rec_loan_year=$total_arrears+$total_loan_rev_year;
$annual_col_rate=$_REQUEST['annual_col_rate'];



$sql="update mic set branch_code='$branch_code', branch_name='$branch_name', region_name='$region_name',date='$date',emp_no ='$emp_no',emp_name='$emp_name',arrears_beg_week='$arrears_beg_week',loan_dis_week='$loan_dis_week',rec_current_loan='$rec_current_loan',earning_rec_amount='$earning_rec_amount',total_rec_loan='$total_rec_loan',current_bor_rate='$current_bor_rate',last_week_gss='$last_week_gss',this_week_gss='$this_week_gss',last_week_sss='$last_week_sss',this_week_sss='$this_week_sss',term_deposit_status='$term_deposit_status',loan_amount_field='$loan_amount_field',ins_arrears_amount='$ins_arrears_amount',ins_arrears_number='$ins_arrears_number',odi_amount='$odi_amount',odi_number='$odi_number',total_arrears='$total_arrears',loan_dis_year='$loan_dis_year',total_loan_rev_year='$total_loan_rev_year',total_rec_loan_year='$total_rec_loan_year',annual_col_rate='$annual_col_rate' where id ='$id'";
$b=mysql_query ($sql);
header('Location:wf1.php');


echo $id;
?>

