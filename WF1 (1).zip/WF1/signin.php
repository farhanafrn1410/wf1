<?php 
session_start();
include("connect.php");
$a="select * from news";
$b=mysql_query($a);

 $username=$_REQUEST['username'];
 $password=$_REQUEST['password'];
 
 $sql = "select * from  user where  Name= '$username' and  Password = '$password'";
 $result = mysql_query($sql) ;
     
 $num = mysql_num_rows($result); 
 


if ($num != 0)
{ 
//please do use the following two lines instead of 3 lines after comment
/* $_SESSION['LoginUserId'] = 'username';
$_SESSION['LoginUserPassword'] = 'password';
*/
	$LoginUserId = $username;
	$LoginUserPassword = $password;  
	
	session_register("LoginUserId", "LoginUserPassword");
	print "<script>window.location='admin_index.php'</script>";	
	exit;
} 
else 
{ 
//please do delete the following two lines
	session_unregister('LoginUserId');
	session_unregister('LoginUserPassword');
	
	session_destroy();
	print "<script>window.location='index.php?id=1'</script>";
	exit;
} 
  


?>