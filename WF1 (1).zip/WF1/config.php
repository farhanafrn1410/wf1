<!--
All code is under the GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007.
-->

<?php
$db_host = "localhost";  // server to connect to.
$db_name = "gournadi_wf1";  // the name of the database.
$db_user = "gournadi_wf1";  // mysql username to access the database with.
$db_pass = "77Sci@90";  // mysql password to access the database with.

?>
